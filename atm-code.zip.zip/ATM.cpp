//
// Created by czy20 on 2025/10/17.
//
#include "ATM.h"
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;
// ATM构造函数
ATM::ATM(const std::string& filename) {
    dataFile = filename;
    currentAccount = nullptr;
    isRunning = true;

    // 创建示例账户
    Account demoAccount("1234567890123456789", "张三", "110101199001011234", "123456");
    Account::saveToFile(demoAccount, dataFile);
}

// ATM析构函数
ATM::~ATM() {

        delete currentAccount;

}

// 显示欢迎界面
void ATM::showWelcome() {
    cout << "==================================" << endl;
    cout << "       欢迎使用ATM模拟系统       " << endl;
    cout << "==================================" << endl;
}

// 显示主菜单
void ATM::showMainMenu() {
    cout << "\n=========== 主菜单 ===========" << endl;
    cout << "1. 余额查询" << endl;
    cout << "2. 取款" << endl;
    cout << "3. 转账" << endl;
    cout << "4. 修改密码" << endl;
    cout << "5. 退卡" << endl;
    cout << "===============================" << endl;
    cout << "请选择操作（1-5）: ";
}

// 登录功能
bool ATM::login() {
    string accountNumber, password;

    cout << "\n请输入账号: ";
    cin >> accountNumber;
    cout << "请输入密码: ";
    cin >> password;

    // 从文件加载账户
    Account account = Account::loadFromFile(accountNumber, dataFile);
    if (account.getAccountNumber().empty()) {
        cout << "账号不存在！" << endl;
        return false;
    }

    if (account.verifyPassword(password)) {
        currentAccount = new Account(account);
        cout << "登录成功！欢迎 " << currentAccount->getName() << "!" << endl;
        return true;
    } else {
        if (account.getIsLocked()) {
            cout << "账户已被锁定，请联系银行！" << endl;
        } else {
            cout << "密码错误！" << endl;
        }
        return false;
    }
}

// 余额查询
void ATM::queryBalance() {
    cout << "\n=========== 余额查询 ===========" << endl;
    cout << "账户: " << currentAccount->getAccountNumber() << endl;
    cout << "姓名: " << currentAccount->getName() << endl;
    cout << "当前余额: ¥" << fixed << setprecision(2) << currentAccount->getBalance() << endl;
    cout << "================================" << endl;
}

// 取款功能
void ATM::withdraw() {
    double amount;
    cout << "\n=========== 取款 ===========" << endl;
    cout << "请输入取款金额（100的整数倍，单笔不超过5000）: ";
    cin >> amount;

    if (currentAccount->withdraw(amount)) {
        cout << "取款成功！取出金额: ¥" << fixed << setprecision(2) << amount << endl;
        cout << "当前余额: ¥" << fixed << setprecision(2) << currentAccount->getBalance() << endl;
        Account::saveToFile(*currentAccount, dataFile);
    } else {
        cout << "取款失败！请检查金额是否符合要求或余额是否充足。" << endl;
    }
}

// 转账功能
void ATM::transfer() {
    string targetAccount;
    double amount;

    cout << "\n=========== 转账 ===========" << endl;
    cout << "请输入转入账户: ";
    cin >> targetAccount;
    cout << "请再次输入转入账户: ";
    cin >> targetAccount;

    cout << "请输入转账金额: ";
    cin >> amount;

    if (currentAccount->transfer(amount)) {
        cout << "转账成功！转账金额: ¥" << fixed << setprecision(2) << amount << endl;
        cout << "当前余额: ¥" << fixed << setprecision(2) << currentAccount->getBalance() << endl;
        Account::saveToFile(*currentAccount, dataFile);
    } else {
        cout << "转账失败！请检查金额是否超过余额。" << endl;
    }
}

// 修改密码
void ATM::changePassword() {
    string newPassword, confirmPassword;

    cout << "\n=========== 修改密码 ===========" << endl;
    cout << "请输入新密码（6位数字）: ";
    cin >> newPassword;
    cout << "请再次输入新密码: ";
    cin >> confirmPassword;

    if (newPassword != confirmPassword) {
        cout << "两次输入的密码不一致！" << endl;
        return;
    }

    if (currentAccount->changePassword(newPassword)) {
        cout << "密码修改成功！" << endl;
        Account::saveToFile(*currentAccount, dataFile);
    } else {
        cout << "密码修改失败！请确保密码为6位数字。" << endl;
    }
}

// 退卡
void ATM::logout() {
    if (currentAccount != nullptr) {
        cout << "感谢使用，再见 " << currentAccount->getName() << "!" << endl;
        delete currentAccount;
        currentAccount = nullptr;
    }
}

// 运行ATM
void ATM::run() {
    showWelcome();

    // 登录循环
    while (isRunning && currentAccount == nullptr) {
        if (!login()) {
            int choice;
            cout << "\n1. 重新登录" << endl;
            cout << "2. 退出系统" << endl;
            cout << "请选择: ";
            cin >> choice;

            if (choice == 2) {
                isRunning = false;
            }
        }
    }

    // 主操作循环
    while (isRunning && currentAccount != nullptr) {
        showMainMenu();

        int choice;
        cin >> choice;

        switch (choice) {
            case 1:
                queryBalance();
                break;
            case 2:
                withdraw();
                break;
            case 3:
                transfer();
                break;
            case 4:
                changePassword();
                break;
            case 5:
                logout();
                isRunning = false;
                break;
            default:
                cout << "无效选择，请重新输入！" << endl;
                break;
        }
    }

    cout << "\n感谢使用ATM模拟系统！" << endl;
}