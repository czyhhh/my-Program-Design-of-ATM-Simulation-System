//
// Created by czy20 on 2025/10/17.
//

#ifndef ATM_ATM_H
#define ATM_ATM_H

#endif //ATM_ATM_H
#ifndef ATM_H
#define ATM_H

#include "Account.h"
#include <string>

class ATM {
private:
    Account* currentAccount;    // 当前登录账户
    bool isRunning;             // ATM运行状态
    std::string dataFile;       // 数据文件路径

    // 私有方法
    static void showWelcome();
    static void showMainMenu();
    bool login();
    void queryBalance();
    void withdraw();
    void transfer();
    void changePassword();
    void logout();

public:
    explicit ATM(const std::string& filename = "accounts.dat");
    ~ATM();

    void run();  // 启动ATM
};

#endif