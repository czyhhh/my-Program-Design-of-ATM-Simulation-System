//
// Created by czy20 on 2025/10/17.
#include "Account.h"
#include <fstream>
#include <iostream>
#include <cctype>

using namespace std;

// 构造函数
Account::Account(const std::string& accNum, const std::string& userName,
                 const std::string& cardId, const std::string& pwd, double bal) {
    accountNumber = accNum;
    name = userName;
    idCard = cardId;
    password = pwd;
    balance = bal;
    isLocked = false;
    wrongPasswordCount = 0;
}

// 获取账号
std::string Account::getAccountNumber() const {
    return accountNumber;
}

// 获取姓名
std::string Account::getName() const {
    return name;
}

// 获取身份证
std::string Account::getIdCard() const {
    return idCard;
}

// 获取余额
double Account::getBalance() const {
    return balance;
}

// 获取是否锁定
bool Account::getIsLocked() const {
    return isLocked;
}

// 验证密码
bool Account::verifyPassword(const std::string& pwd) {
    if (isLocked) {
        return false;
    }

    if (password == pwd) {
        wrongPasswordCount = 0;
        return true;
    } else {
        wrongPasswordCount++;
        if (wrongPasswordCount >= 3) {
            lockAccount();
        }
        return false;
    }
}

// 取款
bool Account::withdraw(double amount) {
    if (amount <= 0 || amount > balance) {
        return false;
    }

    // 检查是否为100的整数倍
    if (static_cast<int>(amount) % 100 != 0) {
        return false;
    }

    // 单笔限额5000元
    if (amount > 5000) {
        return false;
    }

    balance -= amount;
    return true;
}

// 转账
bool Account::transfer(double amount) {
    if (amount <= 0 || amount > balance) {
        return false;
    }

    balance -= amount;
    return true;
}

// 修改密码
bool Account::changePassword(const std::string& newPwd) {
    if (newPwd.length() != 6) {
        return false;
    }

    // 检查是否为纯数字
    for (char c : newPwd) {
        if (!isdigit(c)) {
            return false;
        }
    }

    password = newPwd;
    return true;
}

// 重置错误计数
void Account::resetWrongPasswordCount() {
    wrongPasswordCount = 0;
}

// 锁定账户
void Account::lockAccount() {
    isLocked = true;
}

// 保存到文件
bool Account::saveToFile(const Account& account, const std::string& filename) {
    ofstream file(filename, ios::app);
    if (!file) {
        return false;
    }

    file << account.accountNumber << " "
         << account.name << " "
         << account.idCard << " "
         << account.password << " "
         << account.balance << " "
         << account.isLocked << " "
         << account.wrongPasswordCount << endl;

    file.close();
    return true;
}

// 从文件加载
Account Account::loadFromFile(const std::string& accountNumber, const std::string& filename) {
    ifstream file(filename);
    if (!file) {
        return Account("", "", "", "", 0);
    }

    std::string accNum, name, idCard, password;
    double balance;
    bool isLocked;
    int wrongCount;

    while (file >> accNum >> name >> idCard >> password >> balance >> isLocked >> wrongCount) {
        if (accNum == accountNumber) {
            Account account(accNum, name, idCard, password, balance);
            if (isLocked) {
                account.lockAccount();
            }
            return account;
        }
    }

    file.close();
    return Account("", "", "", "", 0);
}