//
// Created by czy20 on 2025/10/17.
//

#ifndef ATM_ACCOUNT_H
#define ATM_ACCOUNT_H

#endif //ATM_ACCOUNT_H
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>

class Account {
private:
    std::string accountNumber;  // 19位账号
    std::string name;           // 姓名
    std::string idCard;         // 18位身份证
    std::string password;       // 6位密码
    double balance;             // 余额
    bool isLocked;              // 是否锁定
    int wrongPasswordCount;     // 密码错误次数

public:
    // 构造函数
    Account(const std::string& accNum, const std::string& userName,
            const std::string& cardId, const std::string& pwd, double bal = 10000.0);

    // 获取信息方法
    std::string getAccountNumber() const;
    std::string getName() const;
    std::string getIdCard() const;
    double getBalance() const;
    bool getIsLocked() const;

    // 业务操作方法
    bool verifyPassword(const std::string& pwd);
    bool withdraw(double amount);
    bool transfer(double amount);
    bool changePassword(const std::string& newPwd);
    void resetWrongPasswordCount();
    void lockAccount();

    // 文件操作方法
    static bool saveToFile(const Account& account, const std::string& filename);
    static Account loadFromFile(const std::string& accountNumber, const std::string& filename);
};

#endif