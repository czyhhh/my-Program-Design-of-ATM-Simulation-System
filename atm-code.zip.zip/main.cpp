
    // TIP 请访问 <a href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a> 查看 CLion 帮助。此外，您还可以从主菜单中选择“帮助 | 学习 IDE 功能”，尝试 CLion 的交互式课次。
#include <iostream>
#include "ATM.h"
#include <windows.h>

int main() {
    // 设置控制台输出为UTF-8编码
    SetConsoleOutputCP(65001);

    // 你原有的代码
    ATM atm;
    atm.run();
    return 0;
}